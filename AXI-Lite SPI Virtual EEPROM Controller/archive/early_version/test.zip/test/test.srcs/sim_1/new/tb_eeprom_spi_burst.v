`timescale 1ns/1ps

module tb_eeprom_spi_burst;

  // ============================================================
  // clk_i / rst_i  (internal sync clock domain)
  // ============================================================
  reg clk_i = 1'b0;
  reg rst_i = 1'b1;
  always #5 clk_i = ~clk_i;  // 100MHz

  // ============================================================
  // SPI pins driven by TB
  // ============================================================
  reg  sclk_i = 1'b0;
  reg  csn_i  = 1'b1;
  reg  mosi_i = 1'b0;
  wire miso_o;
  wire miso_t_o;

  // DUT
  eeprom_spi dut (
    .clk_i    (clk_i),
    .rst_i    (rst_i),
    .sclk_i   (sclk_i),
    .csn_i    (csn_i),
    .mosi_i   (mosi_i),
    .miso_o   (miso_o),
    .miso_t_o (miso_t_o)
  );

  // ============================================================
  // Parameters
  // ============================================================
  parameter integer T_SCLK = 80; // SPI period (ns). Keep slow vs clk_i for sync safety.
  parameter integer LEN    = 16;

  // readback buffer (global)
  reg [7:0] rbuf [0:255];

  reg pass, fail;
  integer k;

  // ============================================================
  // Small helpers
  // ============================================================
  task spi_wait_half;
    begin
      #(T_SCLK/2);
    end
  endtask

  task spi_cs_low;
    begin
      csn_i = 1'b0;
      // allow synchronizers to settle
      repeat (4) @(posedge clk_i);
    end
  endtask

  task spi_cs_high;
    begin
      csn_i = 1'b1;
      repeat (4) @(posedge clk_i);
    end
  endtask

  // ============================================================
  // SPI byte transfer (Mode0-ish for this model)
  // - Drive MOSI before rising edge
  // - DUT samples MOSI on rising edge
  // - DUT shifts MISO on falling edge (in READ state)
  // We sample MISO on rising edge to reconstruct the byte.
  // ============================================================
  task spi_xfer_byte;
    input  [7:0] tx;
    output [7:0] rx;
    integer b;
    reg bit_in;
    begin
      rx = 8'h00;

      for (b = 7; b >= 0; b = b - 1) begin
        // setup MOSI for this bit
        mosi_i = tx[b];

        // rising edge
        spi_wait_half();
        sclk_i = 1'b1;

        // sample MISO (MSB-first)
        bit_in = miso_o;
        rx[b] = bit_in;

        // falling edge
        spi_wait_half();
        sclk_i = 1'b0;
      end
    end
  endtask

  // ============================================================
  // Burst write: CMD 0x02 + 16-bit addr + len data bytes
  // Data pattern: base + i
  // ============================================================
  task eeprom_burst_write;
    input [15:0] start_addr;
    input [7:0]  base;
    input integer len;
    integer i;
    reg [7:0] dummy;
    begin
      spi_cs_low();

      spi_xfer_byte(8'h02, dummy);             // WRITE
      spi_xfer_byte(start_addr[15:8], dummy);  // AH
      spi_xfer_byte(start_addr[7:0],  dummy);  // AL

      for (i = 0; i < len; i = i + 1) begin
        spi_xfer_byte(base + i[7:0], dummy);   // data stream, DUT auto addr++
      end

      spi_cs_high();
    end
  endtask

  // ============================================================
  // Burst read: CMD 0x03 + 16-bit addr + read len bytes
  // Stores into global rbuf[0..len-1]
  // ============================================================
  task eeprom_burst_read_to_buf;
    input [15:0] start_addr;
    input integer len;
    integer i;
    reg [7:0] rx;
    begin
      spi_cs_low();

      spi_xfer_byte(8'h03, rx);                // READ
      spi_xfer_byte(start_addr[15:8], rx);     // AH
      spi_xfer_byte(start_addr[7:0],  rx);     // AL

      // Now read len bytes by sending dummy 0xFF
      for (i = 0; i < len; i = i + 1) begin
        spi_xfer_byte(8'hFF, rx);
        rbuf[i] = rx;
      end

      spi_cs_high();
    end
  endtask

  // ============================================================
  // Test sequence
  // ============================================================
  initial begin
    pass = 1'b0;
    fail = 1'b0;

    // init SPI lines
    sclk_i = 1'b0;
    csn_i  = 1'b1;
    mosi_i = 1'b0;

    // reset
    repeat (20) @(posedge clk_i);
    rst_i = 1'b0;
    repeat (20) @(posedge clk_i);

    // -------- Burst write then burst read --------
    eeprom_burst_write(16'h0100, 8'hA0, LEN);

    // optional wait (your model writes immediately, so not required)
    repeat (200) @(posedge clk_i);

    eeprom_burst_read_to_buf(16'h0100, LEN);

    // check
    for (k = 0; k < LEN; k = k + 1) begin
      if (rbuf[k] !== (8'hA0 + k[7:0])) begin
        fail = 1'b1;
      end
    end

    if (!fail) pass = 1'b1;

    repeat (50) @(posedge clk_i);
    $finish;
  end

endmodule
