`timescale 1ns/1ps

module tb_spi_master_minimal_mode0;

  // -------------------------
  // Clock / Reset
  // -------------------------
  reg clk = 1'b0;
  reg rst = 1'b1;
  always #5 clk = ~clk; // 100MHz

  // -------------------------
  // DUT inputs
  // -------------------------
  reg        en_i;
  reg        start_i;
  reg [15:0] div_half_i;
  reg [7:0]  tx_byte_i;
  wire [7:0] rx_byte_o;
  wire       busy_o;
  wire       done_o;

  // SPI pins
  wire sclk_o;
  reg  csn_i;
  wire csn_o;
  wire mosi_o;
  wire miso_i;

  // -------------------------
  // Simple SPI slave model (mode0)
  // returns: rx_to_master = (byte_from_master ^ 8'hFF)
  // sample MOSI on rising edge
  // update MISO on falling edge
  // -------------------------
  reg [7:0] sh_in;
  reg [7:0] sh_out;
  reg [2:0] bitcnt;
  reg       have_byte;

  assign miso_i = (csn_i == 1'b0) ? sh_out[7] : 1'b1; // pull-up when CS high

  always @(posedge sclk_o or posedge csn_i) begin
    if (csn_i) begin
      sh_in     <= 8'h00;
      bitcnt    <= 3'd0;
      have_byte <= 1'b0;
    end else begin
      // rising edge: sample MOSI
      sh_in <= {sh_in[6:0], mosi_o};

      if (bitcnt == 3'd7) begin
        bitcnt    <= 3'd0;
        have_byte <= 1'b1; // one byte received
      end else begin
        bitcnt    <= bitcnt + 3'd1;
        have_byte <= 1'b0;
      end
    end
  end

  always @(negedge sclk_o or posedge csn_i) begin
    if (csn_i) begin
      sh_out <= 8'hFF;
    end else begin
      // if a full byte was just received, prepare response for next byte
      if (have_byte) begin
        sh_out <= (sh_in ^ 8'hFF);
      end else begin
        // shift out during the byte (mode0)
        sh_out <= {sh_out[6:0], 1'b1};
      end
    end
  end

  // -------------------------
  // DUT instance
  // -------------------------
  spi_master_minimal_mode0 dut (
    .clk_i      (clk),
    .rst_i      (rst),

    .en_i       (en_i),
    .start_i    (start_i),
    .div_half_i (div_half_i),
    .tx_byte_i  (tx_byte_i),
    .rx_byte_o  (rx_byte_o),
    .busy_o     (busy_o),
    .done_o     (done_o),

    .sclk_o     (sclk_o),
    .csn_i      (csn_i),
    .csn_o      (csn_o),
    .mosi_o     (mosi_o),
    .miso_i     (miso_i)
  );

  // -------------------------
  // Helpers
  // -------------------------
  task spi_send_byte;
    input [7:0] b;
    output [7:0] r;
    begin
      // wait idle
      while (busy_o) @(posedge clk);

      tx_byte_i <= b;
      start_i   <= 1'b1;
      @(posedge clk);
      start_i   <= 1'b0;

      // wait done pulse
      while (!done_o) @(posedge clk);

      r = rx_byte_o;
      @(posedge clk);
    end
  endtask

  // -------------------------
  // Test sequence
  // -------------------------
  reg [7:0] r0, r1, r2, r3;
  reg pass, fail;

  initial begin
    // init
    en_i       = 1'b0;
    start_i    = 1'b0;
    div_half_i = 16'd5; // 100/(2*5)=10MHz
    tx_byte_i  = 8'h00;
    csn_i      = 1'b1;

    pass = 1'b0;
    fail = 1'b0;

    // reset
    repeat (10) @(posedge clk);
    rst <= 1'b1;
    repeat (20) @(posedge clk);
    rst <= 1'b0;
    repeat (10) @(posedge clk);

    // enable + CS low
    en_i  <= 1'b1;
    csn_i <= 1'b0;
    repeat (5) @(posedge clk);

    // send several bytes back-to-back (CS stays low)
    spi_send_byte(8'hA5, r0); // expect 0x5A (A5^FF)
    spi_send_byte(8'h3C, r1); // expect 0xC3
    spi_send_byte(8'h00, r2); // expect 0xFF
    spi_send_byte(8'hFF, r3); // expect 0x00

    // end frame
    csn_i <= 1'b1;
    repeat (20) @(posedge clk);

    // check
    if ((r0 === (8'hA5 ^ 8'hFF)) &&
        (r1 === (8'h3C ^ 8'hFF)) &&
        (r2 === (8'h00 ^ 8'hFF)) &&
        (r3 === (8'hFF ^ 8'hFF))) begin
      pass = 1'b1;
    end else begin
      fail = 1'b1;
    end

    repeat (50) @(posedge clk);
    $finish;
  end

endmodule
