#include "platform.h"
#include "xil_printf.h"

// ====== IP Base Address (Address Editor) ======
#define AXI_EEPROM_BASE   0x44a00000U

// ====== User-defined test vectors ======
#define DIV_HALF          5U
#define WR_ADDR0          0x0033U
#define WR_DATA0          0xABU
#define WR_ADDR1          0x0045U
#define WR_DATA1          0xCDU
#define RD_ADDR0          WR_ADDR1
#define RD_ADDR1          WR_ADDR0

#define SEQ_ADDR          0x0100U
#define SEQ_LEN           16U

// ====== MMIO helpers ======
#define MMIO32(addr)      (*(volatile unsigned int *)(addr))
#define REG32(off)        MMIO32(AXI_EEPROM_BASE + (off))

// ====== Register offsets ======
#define REG_CTRL_OFF      0x00U
#define REG_DIV_OFF       0x04U
#define REG_ADDR_OFF      0x08U
#define REG_WDATA_OFF     0x0CU   // push TX FIFO (low 8 bits)
#define REG_RDATA_OFF     0x10U   // pop RX FIFO  (low 8 bits)
#define REG_STATUS_OFF    0x14U
#define REG_LEN_OFF       0x18U   // LEN [15:0]

// ====== CTRL bits ======
#define CTRL_EN           (1U << 0)
#define CTRL_GO_WR        (1U << 1)
#define CTRL_GO_RD        (1U << 2)

// ====== STATUS bits (minimum used) ======
#define ST_BUSY           (1U << 0)
#define ST_DONE           (1U << 1)

// Optional crude delay
static void m_delay(int cnt)
{
    while (cnt--) {
        volatile int num = 12500;
        while (num--) ;
    }
}

static void wait_not_busy(void)
{
    while (REG32(REG_STATUS_OFF) & ST_BUSY) {;}
}

static void wait_done(void)
{
    // DONE is sticky and read-to-clear when reading STATUS in RTL.
    // So just poll STATUS until DONE appears once.
    while ((REG32(REG_STATUS_OFF) & ST_DONE) == 0U) {;}
}

// ------------------------------------------------------------
// Burst write: write LEN bytes starting at start_addr
// Sequence:
//   wait_not_busy
//   write ADDR
//   write LEN
//   push LEN bytes to WDATA (TX FIFO)
//   trigger GO_WR once
//   wait_done
// ------------------------------------------------------------
static void eeprom_write_seq(unsigned short start_addr,
                             const unsigned char *buf,
                             unsigned int len)
{
    unsigned int i;

    if (len == 0U) return;
    if (len > 16U) len = 16U;  // fixed minimal assumption: FIFO depth 16

    wait_not_busy();

    REG32(REG_ADDR_OFF) = (unsigned int)start_addr;
    REG32(REG_LEN_OFF)  = (unsigned int)(len & 0xFFFFU);

    // push data stream into TX FIFO
    for (i = 0; i < len; i++) {
        REG32(REG_WDATA_OFF) = (unsigned int)(buf[i] & 0xFFU);
    }

    // trigger once
    REG32(REG_CTRL_OFF) = (CTRL_EN | CTRL_GO_WR);

    wait_done();
}

// ------------------------------------------------------------
// Burst read: read LEN bytes starting at start_addr into buf
// Sequence:
//   wait_not_busy
//   write ADDR
//   write LEN
//   trigger GO_RD once
//   wait_done  (RX FIFO is filled by HW after done)
//   pop LEN bytes from RDATA (RX FIFO)
// ------------------------------------------------------------
static void eeprom_read_seq(unsigned short start_addr,
                            unsigned char *buf,
                            unsigned int len)
{
    unsigned int i;
    unsigned int tmp;

    if (len == 0U) return;
    if (len > 16U) len = 16U;  // fixed minimal assumption

    wait_not_busy();

    REG32(REG_ADDR_OFF) = (unsigned int)start_addr;
    REG32(REG_LEN_OFF)  = (unsigned int)(len & 0xFFFFU);

    // trigger once
    REG32(REG_CTRL_OFF) = (CTRL_EN | CTRL_GO_RD);

    // wait until HW completed and RX FIFO has LEN bytes
    wait_done();

    // pop LEN bytes
    for (i = 0; i < len; i++) {
        tmp = REG32(REG_RDATA_OFF);
        buf[i] = (unsigned char)(tmp & 0xFFU);
    }
}

// ------------------------------------------------------------
// Single-byte helpers implemented as len=1 burst
// ------------------------------------------------------------
static void eeprom_write8(unsigned short addr, unsigned char data)
{
    eeprom_write_seq(addr, &data, 1U);
}

static unsigned char eeprom_read8(unsigned short addr)
{
    unsigned char d = 0U;
    eeprom_read_seq(addr, &d, 1U);
    return d;
}

int main(void)
{
    init_platform();

    unsigned char tx_buf[SEQ_LEN];
    unsigned char rx_buf[SEQ_LEN];
    unsigned int i;

    // set SCLK divider
    REG32(REG_DIV_OFF) = (unsigned int)(DIV_HALF & 0xFFFFU);

    // single write
    eeprom_write8((unsigned short)WR_ADDR0, (unsigned char)WR_DATA0);
    eeprom_write8((unsigned short)WR_ADDR1, (unsigned char)WR_DATA1);

    m_delay(500);

    // single read
    unsigned char r0 = eeprom_read8((unsigned short)RD_ADDR0);
    unsigned char r1 = eeprom_read8((unsigned short)RD_ADDR1);

    xil_printf("DIV_HALF=%u\r\n", (unsigned int)DIV_HALF);
    xil_printf("W0: addr=0x%04x data=0x%02x\r\n", (unsigned int)WR_ADDR0, (unsigned int)WR_DATA0);
    xil_printf("W1: addr=0x%04x data=0x%02x\r\n", (unsigned int)WR_ADDR1, (unsigned int)WR_DATA1);
    xil_printf("R0: addr=0x%04x data=0x%02x\r\n", (unsigned int)RD_ADDR0, (unsigned int)r0);
    xil_printf("R1: addr=0x%04x data=0x%02x\r\n", (unsigned int)RD_ADDR1, (unsigned int)r1);

    // ===== burst test =====
    for (i = 0; i < SEQ_LEN; i++) {
        tx_buf[i] = (unsigned char)(0xA0U + (unsigned char)i);
        rx_buf[i] = 0U;
    }

    eeprom_write_seq((unsigned short)SEQ_ADDR, tx_buf, SEQ_LEN);
    m_delay(500);
    eeprom_read_seq((unsigned short)SEQ_ADDR, rx_buf, SEQ_LEN);

    for (i = 0; i < SEQ_LEN; i++) {
        xil_printf("[0x%04x] W=0x%02x R=0x%02x\r\n",
                   (unsigned int)(SEQ_ADDR + i),
                   (unsigned int)tx_buf[i],
                   (unsigned int)rx_buf[i]);
    }

    cleanup_platform();
    return 0;
}
